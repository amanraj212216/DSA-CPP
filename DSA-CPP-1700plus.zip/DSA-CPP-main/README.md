# DSA-CPP Practice Repository

This repository keeps the original beginner exercises and adds organized, standalone C++ examples for common Data Structures and Algorithms topics.

## How to compile and run

Use a C++17 compiler (GCC/MinGW recommended). Open a terminal in this folder and run, for example:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic 01_arrays.cpp -o arrays
./arrays
```

On Windows, run `arrays.exe` after compiling. Each `.cpp` file has its own `main()` and should be compiled separately; do not compile all source files into one executable together.

## Topics

- Original starter programs: odd/even, marks, salary groups, accumulation and simple examples.
- Arrays, sorting and searching
- Strings and linked lists
- Stack, queue and circular queue
- Recursion and backtracking (including N-Queens and Tower of Hanoi)
- Binary search tree and AVL tree
- Graph BFS/DFS and Dijkstra shortest path
- Dynamic programming and greedy algorithms
- Hashing, heaps, bit manipulation and number theory
- Trie prefix tree

## Notes

Examples are intended for learning and demonstration. Input constraints in algorithm examples should be respected (for example, Dijkstra requires non-negative edge weights). Some algorithms such as recursive Fibonacci are deliberately simple demonstrations rather than performance-optimized solutions.
