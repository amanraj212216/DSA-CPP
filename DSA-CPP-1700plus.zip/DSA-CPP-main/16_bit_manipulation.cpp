// Bit manipulation: odd/even, set/check/toggle bits, count bits and power of two.
#include <iostream>
using namespace std;
bool isOdd(unsigned int n){
return n&1U;
}
bool isSet(unsigned int n,
int bit){
return (n&(1U<<bit))!=0;
}
unsigned int setBit(unsigned int n,
int bit){
return n|(1U<<bit);
}
unsigned int clearBit(unsigned int n,
int bit){
return n&~(1U<<bit);
}
unsigned int toggleBit(unsigned int n,
int bit){
return n^(1U<<bit);
}
int countBits(unsigned int n){
int count=0;
while(n){
n&=(n-1);
++count;
}
return count;
}
bool powerOfTwo(unsigned int n){
return n&&!(n&(n-1));
}
int main(){
unsigned int n=10;
cout<<n<<" odd? "<<isOdd(n)<<'\n';
cout<<"Bit 1 set? "<<isSet(n,
1)<<'\n';
cout<<"Set bit 0: "<<setBit(n,
0)<<'\n';
cout<<"Clear bit 1: "<<clearBit(n,
1)<<'\n';
cout<<"Toggle bit 2: "<<toggleBit(n,
2)<<'\n';
cout<<"Set bits in 15: "<<countBits(15)<<'\n';
cout<<"16 power of two? "<<powerOfTwo(16)<<'\n';
}
