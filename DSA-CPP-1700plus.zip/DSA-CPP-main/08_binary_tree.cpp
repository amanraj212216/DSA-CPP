// Binary search tree: insert, search, traversals, height and node count.
#include <iostream>
#include <algorithm>
using namespace std;
struct Node{
int key;
Node*left;
Node*right;
explicit Node(int x):key(x),
left(nullptr),
right(nullptr){
}
}
;
Node* insert(Node* root,
int x){
if(!root)return new Node(x);
if(x<root->key)root->left=insert(root->left,
x);
else if(x>root->key)root->right=insert(root->right,
x);
return root;
}
bool search(Node* root,
int x){
if(!root)return false;
if(root->key==x)return true;
return x<root->key?search(root->left,
x):search(root->right,
x);
}
void inorder(Node*r){
if(!r)return;
inorder(r->left);
cout<<r->key<<' ';
inorder(r->right);
}
void preorder(Node*r){
if(!r)return;
cout<<r->key<<' ';
preorder(r->left);
preorder(r->right);
}
void postorder(Node*r){
if(!r)return;
postorder(r->left);
postorder(r->right);
cout<<r->key<<' ';
}
int height(Node*r){
if(!r)return 0;
return 1+max(height(r->left),
height(r->right));
}
int countNodes(Node*r){
return r?1+countNodes(r->left)+countNodes(r->right):0;
}
void destroy(Node*r){
if(!r)return;
destroy(r->left);
destroy(r->right);
delete r;
}
int main(){
Node*r=nullptr;
for(int x:{
50,
30,
70,
20,
40,
60,
80}
)r=insert(r,
x);
cout<<"Inorder: ";
inorder(r);
cout<<"\nPreorder: ";
preorder(r);
cout<<"\nPostorder: ";
postorder(r);
cout<<"\nContains 60: "<<search(r,
60)<<"\nHeight: "<<height(r)<<"\nNodes: "<<countNodes(r)<<'\n';
destroy(r);
}
