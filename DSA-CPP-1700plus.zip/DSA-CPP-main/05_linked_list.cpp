// Singly linked list with insert, delete, search, reverse and cleanup.
#include <iostream>
using namespace std;
struct Node{
int data;
Node* next;
explicit Node(int x):data(x),
next(nullptr){
}
}
;
class LinkedList{
Node* head;
public:LinkedList():head(nullptr){
}
~LinkedList(){
clear();
}
void pushFront(int x){
Node*n=new Node(x);
n->next=head;
head=n;
}
void pushBack(int x){
Node*n=new Node(x);
if(!head){
head=n;
return;
}
Node*t=head;
while(t->next)t=t->next;
t->next=n;
}
bool insertAfter(int target,
int x){
Node*t=head;
while(t&&t->data!=target)t=t->next;
if(!t)return false;
Node*n=new Node(x);
n->next=t->next;
t->next=n;
return true;
}
bool erase(int x){
Node*t=head,
*prev=nullptr;
while(t&&t->data!=x){
prev=t;
t=t->next;
}
if(!t)return false;
if(prev)prev->next=t->next;
else head=t->next;
delete t;
return true;
}
bool contains(int x)const{
for(Node*t=head;
t;
t=t->next)if(t->data==x)return true;
return false;
}
void reverse(){
Node*prev=nullptr,
*cur=head;
while(cur){
Node*nxt=cur->next;
cur->next=prev;
prev=cur;
cur=nxt;
}
head=prev;
}
int size()const{
int n=0;
for(Node*t=head;
t;
t=t->next)++n;
return n;
}
void display()const{
for(Node*t=head;
t;
t=t->next)cout<<t->data<<" -> ";
cout<<"NULL\n";
}
void clear(){
while(head){
Node*n=head;
head=head->next;
delete n;
}
}
}
;
int main(){
LinkedList list;
list.pushBack(10);
list.pushBack(20);
list.pushFront(5);
list.insertAfter(10,
15);
cout<<"List: ";
list.display();
cout<<"Contains 20: "<<list.contains(20)<<", size: "<<list.size()<<'\n';
list.erase(10);
list.reverse();
cout<<"Updated: ";
list.display();
}
