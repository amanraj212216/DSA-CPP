// Hashing with unordered_map: frequencies, two-sum and duplicate detection.
#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
using namespace std;
unordered_map<int,
int> frequencies(const vector<int>&a){
unordered_map<int,
int>f;
for(int x:a)++f[x];
return f;
}
pair<int,
int> twoSum(const vector<int>&a,
int target){
unordered_map<int,
int>seen;
for(int i=0;
i<(int)a.size();
++i){
int need=target-a[i];
auto it=seen.find(need);
if(it!=seen.end())return {
it->second,
i}
;
seen[a[i]]=i;
}
return {
-1,
-1}
;
}
bool hasDuplicate(const vector<int>&a){
unordered_set<int>s;
for(int x:a)if(!s.insert(x).second)return true;
return false;
}
int longestConsecutive(const vector<int>&a){
unordered_set<int>s(a.begin(),
a.end());
int best=0;
for(int x:s)if(!s.count(x-1)){
int cur=x,
len=1;
while(s.count(cur+1)){
++cur;
++len;
}
if(len>best)best=len;
}
return best;
}
int main(){
vector<int>a={
2,
7,
11,
2,
3,
7,
8}
;
cout<<"Frequencies:\n";
for(auto [x,
n]:frequencies(a))cout<<x<<": "<<n<<'\n';
auto p=twoSum(a,
9);
cout<<"Two sum indices: "<<p.first<<", "<<p.second<<'\n';
cout<<"Has duplicate: "<<hasDuplicate(a)<<'\n';
cout<<"Longest consecutive length: "<<longestConsecutive({
100,
4,
200,
1,
3,
2}
)<<'\n';
}
