// Heap concepts using STL priority_queue: max heap, min heap and kth largest.
#include <iostream>
#include <vector>
#include <queue>
#include <stdexcept>
using namespace std;
int kthLargest(vector<int>a,
int k){
if(k<1||k>(int)a.size())throw invalid_argument("k out of range");
priority_queue<int,
vector<int>,
greater<int>>q;
for(int x:a){
q.push(x);
if((int)q.size()>k)q.pop();
}
return q.top();
}
vector<int> heapSort(vector<int>a){
priority_queue<int,
vector<int>,
greater<int>>q(a.begin(),
a.end());
vector<int>out;
while(!q.empty()){
out.push_back(q.top());
q.pop();
}
return out;
}
int main(){
priority_queue<int>maxHeap;
priority_queue<int,
vector<int>,
greater<int>>minHeap;
for(int x:{
8,
3,
10,
1,
6}
){
maxHeap.push(x);
minHeap.push(x);
}
cout<<"Max heap order: ";
while(!maxHeap.empty()){
cout<<maxHeap.top()<<' ';
maxHeap.pop();
}
cout<<"\nMin heap order: ";
while(!minHeap.empty()){
cout<<minHeap.top()<<' ';
minHeap.pop();
}
cout<<"\n3rd largest: "<<kthLargest({
8,
3,
10,
1,
6}
,
3)<<"\nHeap sort: ";
for(int x:heapSort({
8,
3,
10,
1,
6}
))cout<<x<<' ';
cout<<'\n';
}
