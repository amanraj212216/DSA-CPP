// Sorting algorithms: bubble, selection, insertion, merge and quick sort.
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void show(const vector<int>& a){
for(int x:a) cout<<x<<' ';
cout<<'\n';
}
void bubbleSort(vector<int>& a){
for(size_t i=0;
i<a.size();
++i){
bool changed=false;
for(size_t j=0;
j+1<a.size()-i;
++j)if(a[j]>a[j+1]){
swap(a[j],
a[j+1]);
changed=true;
}
if(!changed)break;
}
}
void selectionSort(vector<int>& a){
for(size_t i=0;
i<a.size();
++i){
size_t m=i;
for(size_t j=i+1;
j<a.size();
++j)if(a[j]<a[m])m=j;
swap(a[i],
a[m]);
}
}
void insertionSort(vector<int>& a){
for(size_t i=1;
i<a.size();
++i){
int key=a[i];
int j=(int)i-1;
while(j>=0&&a[j]>key){
a[j+1]=a[j];
--j;
}
a[j+1]=key;
}
}
void mergeParts(vector<int>& a,
int l,
int m,
int r){
vector<int> left(a.begin()+l,
a.begin()+m+1),
right(a.begin()+m+1,
a.begin()+r+1);
size_t i=0,
j=0;
int k=l;
while(i<left.size()&&j<right.size())a[k++]=(left[i]<=right[j]?left[i++]:right[j++]);
while(i<left.size())a[k++]=left[i++];
while(j<right.size())a[k++]=right[j++];
}
void mergeSort(vector<int>& a,
int l,
int r){
if(l>=r)return;
int m=l+(r-l)/2;
mergeSort(a,
l,
m);
mergeSort(a,
m+1,
r);
mergeParts(a,
l,
m,
r);
}
int partitionArray(vector<int>& a,
int low,
int high){
int pivot=a[high],
i=low-1;
for(int j=low;
j<high;
++j)if(a[j]<=pivot)swap(a[++i],
a[j]);
swap(a[i+1],
a[high]);
return i+1;
}
void quickSort(vector<int>& a,
int low,
int high){
if(low<high){
int p=partitionArray(a,
low,
high);
quickSort(a,
low,
p-1);
quickSort(a,
p+1,
high);
}
}
int main(){
vector<int> original={
9,
4,
1,
7,
3,
8,
2}
;
vector<int> a=original;
bubbleSort(a);
cout<<"Bubble: ";
show(a);
a=original;
selectionSort(a);
cout<<"Selection: ";
show(a);
a=original;
insertionSort(a);
cout<<"Insertion: ";
show(a);
a=original;
mergeSort(a,
0,
(int)a.size()-1);
cout<<"Merge: ";
show(a);
a=original;
quickSort(a,
0,
(int)a.size()-1);
cout<<"Quick: ";
show(a);
}
