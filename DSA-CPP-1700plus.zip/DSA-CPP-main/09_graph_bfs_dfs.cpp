// Graph traversal using adjacency lists, breadth-first search and depth-first search.
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
using Graph=vector<vector<int>>;
void addEdge(Graph& g,
int u,
int v,
bool directed=false){
g[u].push_back(v);
if(!directed)g[v].push_back(u);
}
void bfs(const Graph& g,
int start){
vector<bool> seen(g.size(),
false);
queue<int> q;
q.push(start);
seen[start]=true;
while(!q.empty()){
int u=q.front();
q.pop();
cout<<u<<' ';
for(int v:g[u])if(!seen[v]){
seen[v]=true;
q.push(v);
}
}
cout<<'\n';
}
void dfsVisit(const Graph&g,
int u,
vector<bool>&seen){
seen[u]=true;
cout<<u<<' ';
for(int v:g[u])if(!seen[v])dfsVisit(g,
v,
seen);
}
void dfs(const Graph&g,
int start){
vector<bool>seen(g.size(),
false);
dfsVisit(g,
start,
seen);
cout<<'\n';
}
int connectedComponents(const Graph&g){
vector<bool>seen(g.size(),
false);
int components=0;
for(size_t i=0;
i<g.size();
++i)if(!seen[i]){
++components;
queue<int>q;
q.push((int)i);
seen[i]=true;
while(!q.empty()){
int u=q.front();
q.pop();
for(int v:g[u])if(!seen[v]){
seen[v]=true;
q.push(v);
}
}
}
return components;
}
int main(){
Graph g(6);
addEdge(g,
0,
1);
addEdge(g,
0,
2);
addEdge(g,
1,
3);
addEdge(g,
2,
4);
addEdge(g,
4,
5);
cout<<"BFS from 0: ";
bfs(g,
0);
cout<<"DFS from 0: ";
dfs(g,
0);
cout<<"Components: "<<connectedComponents(g)<<'\n';
}
