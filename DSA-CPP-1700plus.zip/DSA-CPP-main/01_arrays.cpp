// Arrays: traversal, insertion, deletion, search, reverse, rotate and prefix sums.
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
void print(const vector<int>& a) {
for (int x : a) cout << x << ' ';
cout << '\n';
}
int linearSearch(const vector<int>& a,
int key) {
for (int i=0;
i<(int)a.size();
++i) if(a[i]==key) return i;
return -1;
}
void reverseArray(vector<int>& a) {
int l=0,
r=(int)a.size()-1;
while(l<r) swap(a[l++],
a[r--]);
}
void rotateLeft(vector<int>& a,
int k) {
if(a.empty()) return;
k%=a.size();
reverse(a.begin(),
a.begin()+k);
reverse(a.begin()+k,
a.end());
reverse(a.begin(),
a.end());
}
vector<long long> prefixSums(const vector<int>& a) {
vector<long long> p(a.size());
long long sum=0;
for(size_t i=0;
i<a.size();
++i){
sum+=a[i];
p[i]=sum;
}
return p;
}
int main(){
vector<int> a={
7,
2,
9,
4,
2,
1}
;
cout<<"Original: ";
print(a);
cout<<"Index of 4: "<<linearSearch(a,
4)<<'\n';
a.insert(a.begin()+2,
100);
cout<<"After insertion: ";
print(a);
a.erase(a.begin()+2);
cout<<"After deletion: ";
print(a);
reverseArray(a);
cout<<"Reversed: ";
print(a);
rotateLeft(a,
2);
cout<<"Rotated left by 2: ";
print(a);
cout<<"Prefix sums: ";
for(auto x:prefixSums(a)) cout<<x<<' ';
cout<<'\n';
return 0;
}
