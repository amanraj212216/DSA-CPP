// Backtracking: generate subsets, permutations and solve N-Queens.
#include <iostream>
#include <vector>
#include <string>
using namespace std;
void subsets(const vector<int>&a,
int i,
vector<int>&cur){
if(i==(int)a.size()){
cout<<'{';
for(int x:cur)cout<<x<<' ';
cout<<"} ";
return;
}
subsets(a,
i+1,
cur);
cur.push_back(a[i]);
subsets(a,
i+1,
cur);
cur.pop_back();
}
void permutations(string&s,
int pos){
if(pos==(int)s.size()){
cout<<s<<' ';
return;
}
for(int i=pos;
i<(int)s.size();
++i){
swap(s[pos],
s[i]);
permutations(s,
pos+1);
swap(s[pos],
s[i]);
}
}
bool safe(const vector<int>&col,
int row,
int c){
for(int r=0;
r<row;
++r)if(col[r]==c||abs(col[r]-c)==row-r)return false;
return true;
}
void placeQueens(vector<int>&col,
int row,
int n,
int&solutions){
if(row==n){
++solutions;
cout<<"Solution "<<solutions<<": ";
for(int c:col)cout<<c<<' ';
cout<<'\n';
return;
}
for(int c=0;
c<n;
++c)if(safe(col,
row,
c)){
col[row]=c;
placeQueens(col,
row+1,
n,
solutions);
col[row]=-1;
}
}
int main(){
vector<int>cur;
cout<<"Subsets: ";
subsets({
1,
2,
3}
,
0,
cur);
cout<<"\nPermutations of ABC: ";
string s="ABC";
permutations(s,
0);
cout<<"\nN-Queens for n=4:\n";
vector<int>col(4,
-1);
int solutions=0;
placeQueens(col,
0,
4,
solutions);
cout<<"Total solutions: "<<solutions<<'\n';
}
