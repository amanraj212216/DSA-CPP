// Number theory: gcd, lcm, primality, sieve and fast exponentiation.
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long gcdValue(long long a,
long long b){
while(b){
long long r=a%b;
a=b;
b=r;
}
return a<0?-a:a;
}
long long lcmValue(long long a,
long long b){
if(a==0||b==0)return 0;
return (a/gcdValue(a,
b))*b;
}
bool isPrime(int n){
if(n<2)return false;
for(int i=2;
i<=n/i;
++i)if(n%i==0)return false;
return true;
}
vector<int> sieve(int n){
vector<bool>prime(n+1,
true);
if(n>=0)prime[0]=false;
if(n>=1)prime[1]=false;
for(int p=2;
p<=n/p;
++p)if(prime[p])for(int x=p*p;
x<=n;
x+=p)prime[x]=false;
vector<int>out;
for(int i=2;
i<=n;
++i)if(prime[i])out.push_back(i);
return out;
}
long long fastPower(long long base,
long long exp,
long long mod){
long long result=1%mod;
base%=mod;
while(exp>0){
if(exp&1)result=result*base%mod;
base=base*base%mod;
exp>>=1;
}
return result;
}
int main(){
cout<<"gcd(84,30): "<<gcdValue(84,
30)<<'\n';
cout<<"lcm(12,18): "<<lcmValue(12,
18)<<'\n';
cout<<"97 prime? "<<isPrime(97)<<'\n';
cout<<"Primes <= 30: ";
for(int p:sieve(30))cout<<p<<' ';
cout<<"\n3^13 mod 1000: "<<fastPower(3,
13,
1000)<<'\n';
}
