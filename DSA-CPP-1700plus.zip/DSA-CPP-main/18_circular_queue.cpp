// Circular queue implementation with fixed capacity and overflow/underflow checks.
#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;
class CircularQueue{
vector<int>data;
int frontIndex,
rearIndex,
count;
public:explicit CircularQueue(int capacity):data(capacity),
frontIndex(0),
rearIndex(0),
count(0){
if(capacity<=0)throw invalid_argument("capacity must be positive");
}
bool empty()const{
return count==0;
}
bool full()const{
return count==(int)data.size();
}
int size()const{
return count;
}
void enqueue(int x){
if(full())throw overflow_error("queue is full");
data[rearIndex]=x;
rearIndex=(rearIndex+1)%data.size();
++count;
}
int dequeue(){
if(empty())throw underflow_error("queue is empty");
int x=data[frontIndex];
frontIndex=(frontIndex+1)%data.size();
--count;
return x;
}
int front()const{
if(empty())throw underflow_error("queue is empty");
return data[frontIndex];
}
void display()const{
for(int i=0;
i<count;
++i)cout<<data[(frontIndex+i)%data.size()]<<' ';
cout<<'\n';
}
}
;
int main(){
CircularQueue q(4);
q.enqueue(10);
q.enqueue(20);
q.enqueue(30);
cout<<"Queue: ";
q.display();
cout<<"Removed: "<<q.dequeue()<<'\n';
q.enqueue(40);
q.enqueue(50);
cout<<"After wraparound: ";
q.display();
cout<<"Front: "<<q.front()<<", size: "<<q.size()<<'\n';
}
