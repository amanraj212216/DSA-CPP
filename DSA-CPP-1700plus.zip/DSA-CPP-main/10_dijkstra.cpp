// Dijkstra shortest paths for a graph with non-negative edge weights.
#include <iostream>
#include <vector>
#include <queue>
#include <limits>
using namespace std;
using Edge=pair<int,
int>;
vector<long long> dijkstra(const vector<vector<Edge>>& g,
int source){
const long long INF=numeric_limits<long long>::max()/4;
vector<long long>d(g.size(),
INF);
priority_queue<pair<long long,
int>,
vector<pair<long long,
int>>,
greater<pair<long long,
int>>>pq;
d[source]=0;
pq.push({
0,
source}
);
while(!pq.empty()){
auto [dist,
u]=pq.top();
pq.pop();
if(dist!=d[u])continue;
for(auto [v,
w]:g[u])if(dist+w<d[v]){
d[v]=dist+w;
pq.push({
d[v],
v}
);
}
}
return d;
}
void addWeightedEdge(vector<vector<Edge>>&g,
int u,
int v,
int w){
g[u].push_back({
v,
w}
);
g[v].push_back({
u,
w}
);
}
int main(){
vector<vector<Edge>>g(5);
addWeightedEdge(g,
0,
1,
4);
addWeightedEdge(g,
0,
2,
1);
addWeightedEdge(g,
2,
1,
2);
addWeightedEdge(g,
1,
3,
1);
addWeightedEdge(g,
2,
3,
5);
addWeightedEdge(g,
3,
4,
3);
auto d=dijkstra(g,
0);
for(size_t i=0;
i<d.size();
++i)cout<<"Distance 0 -> "<<i<<" = "<<d[i]<<'\n';
}
