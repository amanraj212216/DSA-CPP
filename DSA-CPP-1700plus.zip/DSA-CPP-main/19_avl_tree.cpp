// AVL tree insertion with rotations and inorder traversal.
#include <iostream>
#include <algorithm>
using namespace std;
struct Node{
int key,
height;
Node*left;
Node*right;
explicit Node(int k):key(k),
height(1),
left(nullptr),
right(nullptr){
}
}
;
int h(Node*n){
return n?n->height:0;
}
int balance(Node*n){
return n?h(n->left)-h(n->right):0;
}
void update(Node*n){
n->height=1+max(h(n->left),
h(n->right));
}
Node*rotateRight(Node*y){
Node*x=y->left;
Node*t=x->right;
x->right=y;
y->left=t;
update(y);
update(x);
return x;
}
Node*rotateLeft(Node*x){
Node*y=x->right;
Node*t=y->left;
y->left=x;
x->right=t;
update(x);
update(y);
return y;
}
Node*insertAVL(Node*n,
int key){
if(!n)return new Node(key);
if(key<n->key)n->left=insertAVL(n->left,
key);
else if(key>n->key)n->right=insertAVL(n->right,
key);
else return n;
update(n);
int b=balance(n);
if(b>1&&key<n->left->key)return rotateRight(n);
if(b< -1&&key>n->right->key)return rotateLeft(n);
if(b>1&&key>n->left->key){
n->left=rotateLeft(n->left);
return rotateRight(n);
}
if(b< -1&&key<n->right->key){
n->right=rotateRight(n->right);
return rotateLeft(n);
}
return n;
}
void inorder(Node*n){
if(!n)return;
inorder(n->left);
cout<<n->key<<' ';
inorder(n->right);
}
void destroy(Node*n){
if(!n)return;
destroy(n->left);
destroy(n->right);
delete n;
}
int main(){
Node*root=nullptr;
for(int x:{
10,
20,
30,
40,
50,
25}
)root=insertAVL(root,
x);
cout<<"AVL inorder: ";
inorder(root);
cout<<"\nRoot: "<<root->key<<", height: "<<h(root)<<'\n';
destroy(root);
}
