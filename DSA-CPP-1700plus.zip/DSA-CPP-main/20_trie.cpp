// Trie data structure for lowercase English words: insert, search and prefix check.
#include <iostream>
#include <array>
#include <string>
using namespace std;
struct TrieNode{
array<TrieNode*,
26>next{
}
;
bool terminal=false;
}
;
class Trie{
TrieNode*root;
void clear(TrieNode*n){
if(!n)return;
for(auto child:n->next)clear(child);
delete n;
}
public:Trie():root(new TrieNode){
}
~Trie(){
clear(root);
}
void insert(const string&word){
TrieNode*cur=root;
for(char c:word){
if(c<'a'||c>'z')continue;
int i=c-'a';
if(!cur->next[i])cur->next[i]=new TrieNode;
cur=cur->next[i];
}
cur->terminal=true;
}
bool search(const string&word)const{
const TrieNode*cur=root;
for(char c:word){
if(c<'a'||c>'z')return false;
cur=cur->next[c-'a'];
if(!cur)return false;
}
return cur->terminal;
}
bool startsWith(const string&prefix)const{
const TrieNode*cur=root;
for(char c:prefix){
if(c<'a'||c>'z')return false;
cur=cur->next[c-'a'];
if(!cur)return false;
}
return true;
}
}
;
int main(){
Trie t;
for(string w:{
"apple",
"app",
"apply",
"bat"}
)t.insert(w);
cout<<"Search apple: "<<t.search("apple")<<'\n';
cout<<"Search appl: "<<t.search("appl")<<'\n';
cout<<"Prefix appl: "<<t.startsWith("appl")<<'\n';
cout<<"Prefix cat: "<<t.startsWith("cat")<<'\n';
}
