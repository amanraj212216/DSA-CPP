// String algorithms: palindrome, frequency, anagram, reverse words and substring search.
#include <iostream>
#include <string>
#include <algorithm>
#include <unordered_map>
#include <sstream>
using namespace std;
bool palindrome(string s){
int l=0,
r=(int)s.size()-1;
while(l<r){
if(s[l++]!=s[r--])return false;
}
return true;
}
string reversed(string s){
reverse(s.begin(),
s.end());
return s;
}
bool anagram(string a,
string b){
if(a.size()!=b.size())return false;
sort(a.begin(),
a.end());
sort(b.begin(),
b.end());
return a==b;
}
int countVowels(const string& s){
int n=0;
for(char c:s){
c=(char)tolower((unsigned char)c);
if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')++n;
}
return n;
}
string reverseWords(const string& line){
istringstream in(line);
string word,
out;
while(in>>word){
if(!out.empty())out=' '+out;
out=word+out;
}
return out;
}
int naiveSearch(const string& text,
const string& pattern){
if(pattern.empty())return 0;
for(size_t i=0;
i+pattern.size()<=text.size();
++i){
size_t j=0;
while(j<pattern.size()&&text[i+j]==pattern[j])++j;
if(j==pattern.size())return (int)i;
}
return -1;
}
int main(){
string s="level";
cout<<s<<" palindrome? "<<(palindrome(s)?"yes":"no")<<'\n';
cout<<"Reverse of hello: "<<reversed("hello")<<'\n';
cout<<"listen/silent anagrams? "<<(anagram("listen",
"silent")?"yes":"no")<<'\n';
cout<<"Vowels in education: "<<countVowels("education")<<'\n';
cout<<reverseWords("learn data structures")<<'\n';
cout<<"Pattern index: "<<naiveSearch("algorithm practice",
"practice")<<'\n';
}
