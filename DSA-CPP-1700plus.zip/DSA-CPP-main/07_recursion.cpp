// Recursion examples: factorial, Fibonacci, sum, binary conversion and Tower of Hanoi.
#include <iostream>
#include <string>
using namespace std;
long long factorial(int n){
if(n<0)throw invalid_argument("negative factorial");
if(n<=1)return 1;
return n*factorial(n-1);
}
long long fibonacci(int n){
if(n<0)throw invalid_argument("negative index");
if(n<=1)return n;
return fibonacci(n-1)+fibonacci(n-2);
}
int sumToN(int n){
if(n<=0)return 0;
return n+sumToN(n-1);
}
string binary(int n){
if(n<2)return to_string(n);
return binary(n/2)+to_string(n%2);
}
void hanoi(int n,
char from,
char to,
char aux){
if(n==0)return;
hanoi(n-1,
from,
aux,
to);
cout<<"Move disk "<<n<<" from "<<from<<" to "<<to<<'\n';
hanoi(n-1,
aux,
to,
from);
}
int main(){
cout<<"5! = "<<factorial(5)<<'\n';
cout<<"Fibonacci(8) = "<<fibonacci(8)<<'\n';
cout<<"Sum 1..10 = "<<sumToN(10)<<'\n';
cout<<"13 in binary = "<<binary(13)<<'\n';
cout<<"Hanoi for 3 disks:\n";
hanoi(3,
'A',
'C',
'B');
}
