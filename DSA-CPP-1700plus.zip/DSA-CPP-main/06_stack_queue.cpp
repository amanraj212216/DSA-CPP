// Stack and queue implementations using STL containers.
#include <iostream>
#include <stack>
#include <queue>
#include <string>
using namespace std;
bool balancedBrackets(const string& s){
stack<char> st;
for(char c:s){
if(c=='('||c=='['||c=='{')st.push(c);
else if(c==')'||c==']'||c=='}'){
if(st.empty())return false;
char t=st.top();
st.pop();
if((c==')'&&t!='(')||(c==']'&&t!='[')||(c=='}'&&t!='{'))return false;
}
}
return st.empty();
}
string reverseWithStack(const string& s){
stack<char> st;
for(char c:s)st.push(c);
string out;
while(!st.empty()){
out+=st.top();
st.pop();
}
return out;
}
void printQueue(queue<int> q){
while(!q.empty()){
cout<<q.front()<<' ';
q.pop();
}
cout<<'\n';
}
int main(){
stack<int> st;
for(int x:{
10,
20,
30}
)st.push(x);
cout<<"Stack top: "<<st.top()<<'\n';
st.pop();
cout<<"After pop top: "<<st.top()<<'\n';
queue<int> q;
for(int x:{
1,
2,
3,
4}
)q.push(x);
cout<<"Queue: ";
printQueue(q);
cout<<"Reverse: "<<reverseWithStack("DATA")<<'\n';
cout<<"{a+[b*c]} balanced? "<<balancedBrackets("{a+[b*c]}")<<'\n';
}
