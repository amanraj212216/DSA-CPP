// Dynamic programming: Fibonacci, climbing stairs, coin change and 0/1 knapsack.
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long fibDP(int n){
if(n<0)return -1;
vector<long long>dp(n+2,
0);
dp[1]=1;
for(int i=2;
i<=n;
++i)dp[i]=dp[i-1]+dp[i-2];
return dp[n];
}
long long climbStairs(int n){
if(n<0)return 0;
vector<long long>dp(n+2);
dp[0]=1;
for(int i=1;
i<=n;
++i){
dp[i]=dp[i-1];
if(i>=2)dp[i]+=dp[i-2];
}
return dp[n];
}
int coinChange(const vector<int>&coins,
int amount){
const int INF=amount+1;
vector<int>dp(amount+1,
INF);
dp[0]=0;
for(int c:coins)for(int x=c;
x<=amount;
++x)dp[x]=min(dp[x],
dp[x-c]+1);
return dp[amount]==INF?-1:dp[amount];
}
int knapsack(const vector<int>&w,
const vector<int>&v,
int capacity){
vector<int>dp(capacity+1,
0);
for(size_t i=0;
i<w.size();
++i)for(int c=capacity;
c>=w[i];
--c)dp[c]=max(dp[c],
v[i]+dp[c-w[i]]);
return dp[capacity];
}
int main(){
cout<<"Fibonacci(10): "<<fibDP(10)<<'\n';
cout<<"Ways to climb 5 stairs: "<<climbStairs(5)<<'\n';
cout<<"Coins for 11 using 1,5,7: "<<coinChange({
1,
5,
7}
,
11)<<'\n';
cout<<"Knapsack max value: "<<knapsack({
2,
3,
4}
,
{
4,
5,
7}
,
5)<<'\n';
}
