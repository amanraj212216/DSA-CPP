// Greedy algorithms: activity selection, fractional knapsack and minimum coins.
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct Activity{
int start,
finish;
}
;
vector<Activity> selectActivities(vector<Activity>a){
sort(a.begin(),
a.end(),
[](const Activity&x,
const Activity&y){
return x.finish<y.finish;
}
);
vector<Activity>chosen;
int lastFinish=-1;
for(auto x:a)if(x.start>=lastFinish){
chosen.push_back(x);
lastFinish=x.finish;
}
return chosen;
}
struct Item{
double weight,
value;
}
;
double fractionalKnapsack(vector<Item>items,
double capacity){
sort(items.begin(),
items.end(),
[](const Item&a,
const Item&b){
return a.value/a.weight>b.value/b.weight;
}
);
double total=0;
for(auto item:items){
if(capacity<=0)break;
double take=min(capacity,
item.weight);
total+=take*(item.value/item.weight);
capacity-=take;
}
return total;
}
vector<int> greedyCoins(vector<int>coins,
int amount){
sort(coins.rbegin(),
coins.rend());
vector<int>used;
for(int c:coins)while(amount>=c){
amount-=c;
used.push_back(c);
}
if(amount!=0)used.clear();
return used;
}
int main(){
auto a=selectActivities({
{
1,
3}
,
{
2,
5}
,
{
4,
7}
,
{
1,
8}
,
{
8,
9}
}
);
cout<<"Selected activities: ";
for(auto x:a)cout<<'('<<x.start<<','<<x.finish<<") ";
cout<<'\n';
cout<<"Fractional knapsack value: "<<fractionalKnapsack({
{
10,
60}
,
{
20,
100}
,
{
30,
120}
}
,
50)<<'\n';
cout<<"Greedy coins for 63: ";
for(int c:greedyCoins({
1,
5,
10,
25}
,
63))cout<<c<<' ';
cout<<'\n';
}
