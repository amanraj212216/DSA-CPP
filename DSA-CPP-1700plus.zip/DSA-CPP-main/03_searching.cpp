// Searching: linear, binary, first/last occurrence and square-root approximation.
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int linearSearch(const vector<int>& a,
int key){
for(int i=0;
i<(int)a.size();
++i)if(a[i]==key)return i;
return -1;
}
int binarySearch(const vector<int>& a,
int key){
int l=0,
r=(int)a.size()-1;
while(l<=r){
int m=l+(r-l)/2;
if(a[m]==key)return m;
if(a[m]<key)l=m+1;
else r=m-1;
}
return -1;
}
int firstOccurrence(const vector<int>& a,
int key){
int l=0,
r=(int)a.size()-1,
ans=-1;
while(l<=r){
int m=l+(r-l)/2;
if(a[m]>=key){
if(a[m]==key)ans=m;
r=m-1;
}
else l=m+1;
}
return ans;
}
int lastOccurrence(const vector<int>& a,
int key){
int l=0,
r=(int)a.size()-1,
ans=-1;
while(l<=r){
int m=l+(r-l)/2;
if(a[m]<=key){
if(a[m]==key)ans=m;
l=m+1;
}
else r=m-1;
}
return ans;
}
double squareRoot(double x){
if(x<0)return -1;
double l=0,
r=max(1.0,
x);
for(int i=0;
i<100;
++i){
double m=(l+r)/2;
if(m*m<x)l=m;
else r=m;
}
return (l+r)/2;
}
int main(){
vector<int>a={
1,
2,
2,
2,
4,
6,
8,
10}
;
cout<<"Linear index of 6: "<<linearSearch(a,
6)<<'\n';
cout<<"Binary index of 8: "<<binarySearch(a,
8)<<'\n';
cout<<"First 2: "<<firstOccurrence(a,
2)<<", last 2: "<<lastOccurrence(a,
2)<<'\n';
cout<<"sqrt(27) ~= "<<squareRoot(27)<<'\n';
}
